export default function Footer() {
  return <section className="footer"></section>;
}
