// style
import "../../style/dashboardHome.scss";

export default function DashboardHome() {
  return (
    <section className="dashboardHome">
      <div className="description">
        <h1>Welcome to Admin Panel 😀</h1>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas, sint
          placeat nisi quod aspernatur inventore aperiam voluptate optio
          voluptas ad impedit natus quasi ipsa incidunt unde sapiente
          consectetur corporis suscipit.
        </p>
      </div>
    </section>
  );
}
