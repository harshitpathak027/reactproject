import { Outlet } from "react-router-dom";

export default function CreateQuiz() {
  return (
    <section className="createQuiz">
      <Outlet />
    </section>
  );
}
